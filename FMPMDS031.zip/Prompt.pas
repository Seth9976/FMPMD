//============================================================================
//                  �J���I�P�p�R�}���h���C���\���p�t�H�[��
//                      Copyright & Programmed by C60
//============================================================================
unit Prompt;

interface

uses
	Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
	Util, ExtCtrls, ShellAPI, PinForm, DecodeESC, FMPMDPlayDefine,
	WinFMP, PMDWin;

// debug ���[�h�̎��ɗL���ɂ���(�s���ȃG�X�P�[�v�V�[�P���X�ŗ�O�𐶐�����)
//{$DEFINE DEBUG}

type
	TBlinkArray = Array[0..1] of Integer;

const
	NumOfDelayBuffer = 50*2;				// �T�O�t���[���~�Q�b���̒x���o�b�t�@
	STR_MSGOTHIC = '�l�r �S�V�b�N';
  STR_98GRAPHIC = '98Graphics';
	STR_FMPGAIJI = 'FMP�O��';				// �t�H���g��
	EdgeWidth = 3;									// ��ʂ̂ӂ��̕��i�h�b�g���j
	ORG_SCREEN_WIDTH  = 640;				// PC-98x1 �̉����h�b�g��
	ORG_SCREEN_HEIGHT = 400;        // PC-98x1 �̏c���h�b�g��
  BlinkTime : TBlinkArray = (1500, 500);			// �_�Ł^��������(msec �P��)

	WM_PROMPT_MUSICCHANGE				= WM_USER + $100;			// �ȕύX
  		// (wParam = TPlayDriver(FMP or PMD), lParam = �Ȗ��̃|�C���^(�Ăяo����ŊJ��)
	WM_PROMPT_PLAYSTART					= WM_USER + $101;			// ���t�J�n
  WM_PROMPT_PLAYSTOP					= WM_USER + $102;			// ���t��~
  WM_PROMPT_PLAYPAUSE					= WM_USER + $103;			// Pause
  WM_PROMPT_POSITIONMOVESTART	= WM_USER + $104;			// ���t�ʒu�ړ��J�n
	WM_PROMPT_POSITIONMOVEEND		= WM_USER + $105;			// ���t�ʒu�ړ��I��


type
	TPromptForm = class;
	PWord = ^Word;

	//**************************************************************************
	// TPromptThread �N���X
	// �Ȃɓ������ĕ`��R�}���h(�`�敶����A�S��ʃN���A�A�S��ʕ`��)����������
	//**************************************************************************
	TPromptThread = class(TThread)
	private
		{ Private �錾 }
		FOwner : TPromptForm;
		FPlayDriver : TPlayDriver;
		FInterval : Integer;
		FDelay : Integer;
		FMusData : Array[0..FMP_MUSDATASIZE + 32 -1] of Byte;
		pKaraoke : PChar;
		DummyChar : Char;
		SyncScntBuf : Array[0..NumOfDelayBuffer-1] of Integer;	// �x���p�o�b�t�@(WinFMP)
		FPMDWinDraw : Boolean;																	// PMDWin �`��t���O
		DisplayPrompt : Boolean;							// �`�悵�Ă��ǂ����� True
		FLastSyncScnt : Integer;
		FDrawStr : String;
		pw : Integer;               					// �o�b�t�@�������݈ʒu
		pr : Integer;                 				// �o�b�t�@�ǂݏo���ʒu
	protected
		{ Protected �錾 }
		procedure Execute; override;
		procedure SetInterval(Value : Integer);
		procedure SetDelay(Value : Integer);
		procedure InitDisplay;
		procedure DrawDisplay;
		procedure FullDraw;
		procedure MusicChange(Filename : string; PlayDriver : TPlayDriver);
		procedure PlayStart;
		procedure PlayStop;
		procedure PlayPause;
		procedure PositionMoveStart;
		procedure PositionMoveEnd;
		procedure DrawFMPPrompt;
		procedure DrawPMDPrompt;
	public
		{ Public �錾 }
		constructor Create(Owner : TPromptForm);
		destructor Destroy;	override;
		property Interval : Integer read FInterval write SetInterval default 50;
		property Delay : Integer read FDelay write SetDelay default 0;
end;

	//**************************************************************************
	// TPromptBlinkThread �N���X
	// ��ʂ̓_�ł𐧌䂷��
	//**************************************************************************
	TPromptBlinkThread = class(TThread)
	private
		{ Private �錾 }
		FOwner : TPromptForm;
		FInterval : Integer;
		RemainTime : Integer;				// �_�Ł^���Ő؂�ւ��̎c�莞��(msec)
	protected
		{ Protected �錾 }
		procedure Execute; override;
		procedure SetInterval(Value : Integer);
		procedure BlinkDraw;
	public
		{ Public �錾 }
		constructor Create(Owner : TPromptForm);
		property Interval : Integer read FInterval write SetInterval default 50;
  end;


	//**************************************************************************
	// TPromptForm �N���X
	//**************************************************************************
	TPromptForm = class(TForm)
		PinForm1: TPinForm;
		procedure FormCreate(Sender: TObject);
		procedure FormDestroy(Sender: TObject);
		procedure FormResize(Sender: TObject);
    procedure FormPaint(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
	private
		{ Private �錾 }
		PromptThread : TPromptThread;
    PromptBlinkThread : TPromptBlinkThread;
		DecodeESCSequence : TDecodeESCSequence;
		TempBitmap : TBitmap;						// ���`��pBitmap(�Q�o�C�g���p�Ŏg�p)
		FPositionMove : Boolean;				// �`���~(�Đ��ʒu�ړ���)�Ȃ� True(�T�u�X���b�h�Ő���)
		FBlinkOn : Boolean;							// True �Ȃ�_�łŕ`��AFalse �Ȃ�_�łŕ`�悹��
	protected
		{ Protected �錾 }
		procedure WindowPosChanging(var Msg : TWMWindowPosChanging); message WM_WINDOWPOSCHANGING;
		procedure DropFiles(var Msg:TWMDROPFILES); message WM_DROPFILES;
		procedure SetPriority(Value : TThreadPriority);
		function GetPriority : TThreadPriority;
		procedure SetInterval(Value : Integer);
		function GetInterval : Integer;
		procedure SetDelay(Value : Integer);
		function GetDelay : Integer;
		procedure ScroolDisplay(Rect : TRect; ScroolLine : Integer);
		procedure InsertDisplay(Rect : TRect; ScroolLine : Integer);
		procedure WriteDisplay(DecodeESCCommand : TDecodeESCCommand);
		function CalcScreenX(CharX : Integer) : Integer;
		function CalcScreenY(CharY : Integer) : Integer;
		function CalcBitmapX(CharX : Integer) : Integer;
		function CalcBitmapY(CharY : Integer) : Integer;
		function CalcFontHeight : Integer;
		function CalcLineWidth : Integer;
	public
		{ Public �錾 }
		procedure InitDisplay;
		procedure ClearAllDisplay;
		procedure ClearDisplay(Rect : TRect);
		procedure DrawDisplay(DrawStr : string);
		procedure FullDraw;
		procedure BlinkDraw;
		procedure Play_Start(var Msg : TMessage); message WM_PLAYSTART;
		procedure Play_Stop(var Msg : TMessage); message WM_PLAYSTOP;
		procedure Play_Pause(var Msg : TMessage); message WM_PLAYPAUSE;
		procedure PositionMove_Start(var Msg : TMessage); message WM_POSITIONMOVE_START;
		procedure PositionMove_End(var Msg : TMessage); message WM_POSITIONMOVE_END;
		procedure MusicChange(Filename : string; PlayDriver : TPlayDriver);
		property PositionMove : Boolean read FPositionMove write FPositionMove;
		property BlinkOn : Boolean read FBlinkOn write FBlinkOn;
		property Priority : TThreadPriority read GetPriority write SetPriority
																															default tpNormal;
		property Interval : Integer read GetInterval write SetInterval default 50;
		property Delay : Integer read GetDelay write SetDelay default 0;
	end;

var
	PromptForm: TPromptForm;

implementation

uses Main;


{$R *.DFM}


//###########################################################################
//###########################################################################
// TPromptForm �N���X
//###########################################################################
//###########################################################################

//***************************************************************************
// �R���X�g���N�^
//***************************************************************************
procedure TPromptForm.FormCreate(Sender: TObject);
begin
	DragAcceptFiles(Handle, True);
	TempBitmap := TBitmap.Create;

  FPositionMove := False;
  FBlinkOn := True;
	DecodeESCSequence := TDecodeESCSequence.Create;
	PromptThread := TPromptThread.Create(Self);
	PromptBlinkThread := TPromptBlinkThread.Create(Self);
end;


//***************************************************************************
// �f�X�g���N�^
//***************************************************************************
procedure TPromptForm.FormDestroy(Sender: TObject);
begin
	TempBitmap.Free;
	PromptThread.Terminate;
	PromptBlinkThread.Terminate;
	PromptThread.WaitFor;
	PromptBlinkThread.WaitFor;
	PromptThread.Free;
	PromptBlinkThread.Free;
	DecodeESCSequence.Free;
end;


//***************************************************************************
// �t�H�[���ĕ`��
//***************************************************************************
procedure TPromptForm.FormPaint(Sender: TObject);
begin
	FullDraw;
end;


//***************************************************************************
// �t�H�[���̃T�C�Y�ύX
//***************************************************************************
procedure TPromptForm.FormResize(Sender: TObject);
begin
	FullDraw;
end;


//***************************************************************************
// Window �̃X�i�b�v
//***************************************************************************
procedure TPromptForm.WindowPosChanging(var Msg : TWMWindowPosChanging);
begin
	if(FMPMDForm.Snap = True) then begin
		Msg.WindowPos^.x := (Msg.WindowPos^.x div FMPMDForm.SnapWidth) * FMPMDForm.SnapWidth;
		Msg.WindowPos^.y := (Msg.WindowPos^.y div FMPMDForm.SnapWidth) * FMPMDForm.SnapWidth;
		Msg.WindowPos^.cx := (Msg.WindowPos^.cx div FMPMDForm.SnapWidth) * FMPMDForm.SnapWidth;
		Msg.WindowPos^.cy := (Msg.WindowPos^.cy div FMPMDForm.SnapWidth) * FMPMDForm.SnapWidth;
	end;

  inherited;
end;


//***************************************************************************
// Window �ւ� D&D
//***************************************************************************
procedure TPromptForm.DropFiles(var Msg:TWMDROPFILES);
begin
	FMPMDForm.DropFiles(Msg);
end;


//***************************************************************************
// �t�H�[�����J�����Ƃ�
//***************************************************************************
procedure TPromptForm.FormActivate(Sender: TObject);
begin
	FMPMDForm.ConsoleMenu.Checked := True;
end;


//***************************************************************************
// �t�H�[��������Ƃ�
//***************************************************************************
procedure TPromptForm.FormClose(Sender: TObject; var Action: TCloseAction);
begin
	FMPMDForm.ConsoleMenu.Checked := False;
end;


//***************************************************************************
// �v�����v�g�\���J�n
//***************************************************************************
procedure TPromptForm.Play_Start;
begin
	if Assigned(PromptThread) then begin
		PostThreadMessage(PromptThread.ThreadID, WM_PROMPT_PLAYSTART, 0, 0);
	end;
end;


//***************************************************************************
// �v�����v�g�\����~
//***************************************************************************
procedure TPromptForm.Play_Stop;
begin
	if Assigned(PromptThread) then begin
		PostThreadMessage(PromptThread.ThreadID, WM_PROMPT_PLAYSTOP, 0, 0);
	end;
end;


//***************************************************************************
// �v�����v�g�\�� Pause
//***************************************************************************
procedure TPromptForm.Play_Pause;
begin
	if Assigned(PromptThread) then begin
		PostThreadMessage(PromptThread.ThreadID, WM_PROMPT_PLAYPAUSE, 0, 0);
	end;
end;


//***************************************************************************
// �Đ��ʒu�ύX�����J�n
//***************************************************************************
procedure TPromptForm.PositionMove_Start;
begin
	if Assigned(PromptThread) then begin
		PostThreadMessage(PromptThread.ThreadID, WM_PROMPT_POSITIONMOVESTART, 0, 0);
	end;
end;


//***************************************************************************
// �Đ��ʒu�ύX�����I��
//***************************************************************************
procedure TPromptForm.PositionMove_End;
begin
	if Assigned(PromptThread) then begin
		PostThreadMessage(PromptThread.ThreadID, WM_PROMPT_POSITIONMOVEEND, 0, 0);
	end;
end;


//***************************************************************************
// �ȕύX
//***************************************************************************
procedure TPromptForm.MusicChange(Filename : string; PlayDriver : TPlayDriver);
var
	pStr : PChar;
begin
	pStr := StrNew(PChar(FileName));
	PostThreadMessage(PromptThread.ThreadID,
  		WM_PROMPT_MUSICCHANGE, WPARAM(PlayDriver), LPARAM(pStr));
end;


//***************************************************************************
// Priority �擾
//***************************************************************************
function TPromptForm.GetPriority : TThreadPriority;
begin
	if Assigned(PromptThread) then begin
		Result := PromptThread.Priority;
	end else begin
		Result := tpNormal;
	end;
end;

//***************************************************************************
// Priority �ݒ�
//***************************************************************************
procedure TPromptForm.Setpriority(Value : TThreadPriority);
begin
	if Assigned(PromptThread) then begin
		PromptThread.Priority := Value;
	end;
end;


//***************************************************************************
// Interval �擾
//***************************************************************************
function TPromptForm.GetInterval : Integer;
begin
	if Assigned(PromptThread) then begin
		Result := PromptThread.Interval;
	end else begin
		Result := 50;
	end;
end;

//***************************************************************************
// Interval �ݒ�
//***************************************************************************
procedure TPromptForm.SetInterval(Value : Integer);
begin
	if Assigned(PromptThread) then begin
		PromptThread.Interval := Value;
	end;
end;


//***************************************************************************
// Delay �擾
//***************************************************************************
function TPromptForm.GetDelay : Integer;
begin
	if Assigned(PromptThread) then begin
		Result := PromptThread.Delay;
	end else begin
		Result := 0;
	end;
end;

//***************************************************************************
// Delay �ݒ�
//***************************************************************************
procedure TPromptForm.SetDelay(Value : Integer);
begin
	if Assigned(PromptThread) then begin
		PromptThread.Delay := Value;
	end;

end;


//***************************************************************************
// ��ʏ�����
//***************************************************************************
procedure TPromptForm.InitDisplay;
begin
	DecodeESCSequence.Init;
	ClearAllDisplay;
end;


//***************************************************************************
// �S��ʏ���
//***************************************************************************
procedure TPromptForm.ClearAllDisplay;
var
	DestRect : TRect;
begin
	DestRect.Left   := 0;
	DestRect.Top    := 0;
	DestRect.Right  := ClientWidth;
	DestRect.Bottom := ClientHeight;
	Canvas.Brush.Color := clBlack;
	Canvas.Brush.Style := bsSolid;
	Canvas.FillRect(DestRect);
end;


//***************************************************************************
// �S��ʍĕ`��
//***************************************************************************
procedure TPromptForm.FullDraw;
var
	x, y : Integer;
	DecodeESCCommand : TDecodeESCCommand;
	TempChar : Array[0..2] of Char;
begin
	if(FPositionMove = True) then Exit;

	ClearAllDisplay;

	DecodeESCCommand.Command := DECODEESC_WRITE;
	DecodeESCCommand.ScroolLine := 0;
	TempChar[2] := #0;

	for y := 0 to SCREEN_HEIGHT - 1 do begin
		DecodeESCCommand.Rect.Top := y;
		DecodeESCCommand.Rect.Bottom := y;

		// x �𑀍삷��̂� while ���[�v�ɂ���
		x := 0;
		while(x < SCREEN_WIDTH) do begin
			case DecodeESCSequence.VRAM[x, y].Attribute.LetterCode of
			// ASCII
			CHAR_ASCII :
				begin
					// �󔒈ȊO��������`�悷��
					if not(DecodeESCSequence.VRAM[x, y].Letter in [$0, $20]) then begin
						DecodeESCCommand.Rect.Left  := x;
						DecodeESCCommand.Rect.Right := x;
						DecodeESCCommand.Text := Chr(DecodeESCSequence.VRAM[x, y].Letter);
						DecodeESCCommand.Attribute := DecodeESCSequence.VRAM[x, y].Attribute;
						WriteDisplay(DecodeESCCommand);
					end;
					Inc(x);
				end;

			CHAR_GRAPHIC :
				begin
					// �󔒈ȊO��������`�悷��
					if not(DecodeESCSequence.VRAM[x, y].Letter in [$0, $20]) then begin
						DecodeESCCommand.Rect.Left  := x;
						DecodeESCCommand.Rect.Right := x;
						DecodeESCCommand.Text := Chr(DecodeESCSequence.VRAM[x, y].Letter);
						DecodeESCCommand.Attribute := DecodeESCSequence.VRAM[x, y].Attribute;
						WriteDisplay(DecodeESCCommand);
					end;
					Inc(x);
				end;

			// SJIS �P������
			CHAR_SJIS1 :
				begin
{$IFDEF DEBUG}
					if(x + 1 >= SCREEN_WIDTH) then begin
						raise EDecodeESCSequenceError.Create(MSG_ERR_UNDECODE_ESC);
					end else if(DecodeESCSequence.VRAM[x+1, y].Attribute.LetterCode <> CHAR_SJIS2) then begin
						raise EDecodeESCSequenceError.Create(MSG_ERR_UNDECODE_ESC);
					end;
{$ENDIF}
					// �󔒈ȊO��������`�悷��
					if(DecodeESCSequence.VRAM[x, y].Letter <> $81) or
							(DecodeESCSequence.VRAM[x+1, y].Letter <> $40) then begin
						DecodeESCCommand.Rect.Left  := x;
						DecodeESCCommand.Rect.Right := x + 1;
						TempChar[0] := Char(DecodeESCSequence.VRAM[x  , y].Letter);
						TempChar[1] := Char(DecodeESCSequence.VRAM[x+1, y].Letter);
						DecodeESCCommand.Text := String(TempChar);
						DecodeESCCommand.Attribute := DecodeESCSequence.VRAM[x, y].Attribute;
						WriteDisplay(DecodeESCCommand);
					end;
					Inc(x, 2);
				end;

			// �Q�o�C�g���p
			CHAR_ZEN2 :
				begin
					DecodeESCCommand.Rect.Left  := x;
					DecodeESCCommand.Rect.Right := x;
					TempChar[0] := Char(DecodeESCSequence.VRAM[x, y].Letter shr 8);
					TempChar[1] := Char(DecodeESCSequence.VRAM[x, y].Letter and $ff);
					DecodeESCCommand.Text := String(TempChar);
					DecodeESCCommand.Attribute := DecodeESCSequence.VRAM[x, y].Attribute;
					WriteDisplay(DecodeESCCommand);
					Inc(x);
				end;
			else
			// CHAR_SJIS2
{$IFDEF DEBUG}
					raise EDecodeESCSequenceError.Create(MSG_ERR_UNDECODE_ESC);
{$ENDIF}
			end;
		end;
	end;
end;


//***************************************************************************
// �_�ŉ�ʕ`��
//***************************************************************************
procedure TPromptForm.BlinkDraw;
var
	x, y : Integer;
	DecodeESCCommand : TDecodeESCCommand;
	TempChar : Array[0..2] of Char;
begin
	if(FPositionMove = True) then Exit;

	DecodeESCCommand.Command := DECODEESC_WRITE;
	DecodeESCCommand.ScroolLine := 0;
	TempChar[2] := #0;

	for y := 0 to SCREEN_HEIGHT - 1 do begin
		DecodeESCCommand.Rect.Top := y;
		DecodeESCCommand.Rect.Bottom := y;

		// x �𑀍삷��̂� while ���[�v�ɂ���
		x := 0;
		while(x < SCREEN_WIDTH) do begin
			if not(Blink in DecodeESCSequence.VRAM[x, y].Attribute.Attribute_Sub) then begin
				// �_�ňȊO
				if(DecodeESCSequence.VRAM[x, y].Attribute.LetterCode = CHAR_SJIS1) then begin
					// SJIS1
					Inc(x, 2);
				end else begin
					// SJIS2, ASCII, GRAPHIC, �Q�o�C�g���p
					Inc(x);
				end;
			end else begin
				// �_��
				case DecodeESCSequence.VRAM[x, y].Attribute.LetterCode of
				// ASCII
				CHAR_ASCII :
					begin
						// �󔒈ȊO��������`�悷��
						if not(DecodeESCSequence.VRAM[x, y].Letter in [$0, $20]) then begin
							DecodeESCCommand.Rect.Left  := x;
							DecodeESCCommand.Rect.Right := x;
							DecodeESCCommand.Text := Chr(DecodeESCSequence.VRAM[x, y].Letter);
							DecodeESCCommand.Attribute := DecodeESCSequence.VRAM[x, y].Attribute;
							WriteDisplay(DecodeESCCommand);
						end;
						Inc(x);
					end;

				CHAR_GRAPHIC :
					begin
						// �󔒈ȊO��������`�悷��
						if not(DecodeESCSequence.VRAM[x, y].Letter in [$0, $20]) then begin
							DecodeESCCommand.Rect.Left  := x;
							DecodeESCCommand.Rect.Right := x;
							DecodeESCCommand.Text := Chr(DecodeESCSequence.VRAM[x, y].Letter);
							DecodeESCCommand.Attribute := DecodeESCSequence.VRAM[x, y].Attribute;
							WriteDisplay(DecodeESCCommand);
						end;
						Inc(x);
					end;

				// SJIS �P������
				CHAR_SJIS1 :
					begin
{$IFDEF DEBUG}
						if(x + 1 >= SCREEN_WIDTH) then begin
							raise EDecodeESCSequenceError.Create(MSG_ERR_UNDECODE_ESC);
						end else if(DecodeESCSequence.VRAM[x+1, y].Attribute.LetterCode <> CHAR_SJIS2) then begin
							raise EDecodeESCSequenceError.Create(MSG_ERR_UNDECODE_ESC);
						end;
{$ENDIF}
						// �󔒈ȊO��������`�悷��
						if(DecodeESCSequence.VRAM[x, y].Letter <> $81) or
								(DecodeESCSequence.VRAM[x+1, y].Letter <> $40) then begin
							DecodeESCCommand.Rect.Left  := x;
							DecodeESCCommand.Rect.Right := x + 1;
							TempChar[0] := Char(DecodeESCSequence.VRAM[x  , y].Letter);
							TempChar[1] := Char(DecodeESCSequence.VRAM[x+1, y].Letter);
							DecodeESCCommand.Text := String(TempChar);
							DecodeESCCommand.Attribute := DecodeESCSequence.VRAM[x, y].Attribute;
							WriteDisplay(DecodeESCCommand);
						end;
						Inc(x, 2);
					end;

				// �Q�o�C�g���p
				CHAR_ZEN2 :
					begin
						DecodeESCCommand.Rect.Left  := x;
						DecodeESCCommand.Rect.Right := x;
						TempChar[0] := Char(DecodeESCSequence.VRAM[x, y].Letter shr 8);
						TempChar[1] := Char(DecodeESCSequence.VRAM[x, y].Letter and $ff);
						DecodeESCCommand.Text := String(TempChar);
						DecodeESCCommand.Attribute := DecodeESCSequence.VRAM[x, y].Attribute;
						WriteDisplay(DecodeESCCommand);
						Inc(x);
					end;
				else
					// CHAR_SJIS2
{$IFDEF DEBUG}
					raise EDecodeESCSequenceError.Create(MSG_ERR_UNDECODE_ESC);
{$ENDIF}
				end;
			end;
		end;
	end;
end;


//***************************************************************************
// ��ʕ`��
//***************************************************************************
procedure TPromptForm.DrawDisplay(DrawStr : String);
var
	i : Integer;
	DecodeESCCommandList : TDecodeESCCommandList;
begin
	DecodeESCCommandList := TDecodeESCCommandList.Create;
	try
		DecodeESCSequence.DecodeESCSequence(DrawStr, DecodeESCCommandList);

		if(FPositionMove = True) then Exit;

		for i := 0 to DecodeESCCommandList.Count - 1 do begin
			case DecodeESCCommandList[i]^.Command of
			DECODEESC_CLEAR :		// ��ʏ���
				begin
					ClearDisplay(DecodeESCCommandList[i]^.Rect);
				end;

			DECODEESC_SCROOL :	// �X�N���[��
				begin
					ScroolDisplay(DecodeESCCommandList[i]^.Rect, DecodeESCCommandList[i]^.ScroolLine);
				end;

			DECODEESC_INSERT :	// �󔒍s�}��
				begin
					InsertDisplay(DecodeESCCommandList[i]^.Rect, DecodeESCCommandList[i]^.ScroolLine);
				end;

			DECODEESC_WRITE :		// �����`��
				begin
					WriteDisplay(DecodeESCCommandList[i]^);
				end;
			end;
		end;
	finally
		DecodeESCCommandList.Free;
	end;
end;


//***************************************************************************
// ��ʏ���
//***************************************************************************
procedure TPromptForm.ClearDisplay(Rect : TRect);
var
	DestRect : TRect;
begin
	DestRect.Left   := CalcScreenX(Rect.Left);
	DestRect.Top    := CalcScreenY(Rect.Top );
	DestRect.Right  := CalcScreenX(Rect.Right  + 1);
	DestRect.Bottom := CalcScreenY(Rect.Bottom + 1);
	Canvas.Brush.Color := clBlack;
	Canvas.Brush.Style := bsSolid;
	Canvas.FillRect(DestRect);
end;


//***************************************************************************
// �X�N���[��
//***************************************************************************
procedure TPromptForm.ScroolDisplay(Rect : TRect; ScroolLine : Integer);
var
	SourceRect : TRect;
	DestRect : TRect;
	i : Integer;
begin
	// �d�����ǌ덷��h�����߂ɂP�s�ÂX�N���[������
	SourceRect.Left  := CalcScreenX(0);
	SourceRect.Right := CalcScreenX(SCREEN_WIDTH);
	DestRect.Left    := SourceRect.Left;
	DestRect.Right   := SourceRect.Right;

	for i := 0 to Rect.Bottom - Rect.Top - ScroolLine do begin
		SourceRect.Top    := CalcScreenY(Rect.Top + i + ScroolLine);
		SourceRect.Bottom := CalcScreenY(Rect.Top + i + ScroolLine + 1);
		DestRect.Top      := CalcScreenY(Rect.Top + i);
		DestRect.Bottom   := CalcScreenY(Rect.Top + i + 1);

		// �X�N���[��
		Canvas.CopyRect(DestRect, Canvas, SourceRect);

	end;

// �X�N���[��������h��Ԃ�
SourceRect.Top    := CalcScreenY(Rect.Bottom - ScroolLine + 1);
SourceRect.Bottom := CalcScreenY(Rect.Bottom + 1);
Canvas.Brush.Color := clBlack;
Canvas.Brush.Style := bsSolid;
Canvas.FillRect(SourceRect);

// ��ʂ�ۑ�
//	Image1.Picture.Bitmap.SaveToFile('r:\test.bmp');	//@ for debug
end;


//***************************************************************************
// �󔒍s�}��
//***************************************************************************
procedure TPromptForm.InsertDisplay(Rect : TRect; ScroolLine : Integer);
var
	SourceRect : TRect;
	DestRect : TRect;
	i : Integer;
begin
	// �d�����ǌ덷��h�����߂ɂP�s�Âړ�����
	SourceRect.Left  := CalcScreenX(0);
	SourceRect.Right := CalcScreenX(SCREEN_WIDTH);
	DestRect.Left    := CalcScreenX(0);
	DestRect.Right   := CalcScreenX(SCREEN_WIDTH);

	for i := 0 to Rect.Bottom - Rect.Top - ScroolLine do begin
		SourceRect.Top    := CalcScreenY(Rect.Bottom - (ScroolLine - 1) - i);
		SourceRect.Bottom := CalcScreenY(Rect.Bottom - (ScroolLine - 1) - i + 1);
		DestRect.Top      := CalcScreenY(Rect.Bottom - i);
		DestRect.Bottom   := CalcScreenY(Rect.Bottom - i + 1);

		// �ړ�
		Canvas.CopyRect(DestRect, Canvas, SourceRect);
	end;

	// �}���㕔��h��Ԃ�
	SourceRect.Top    := CalcScreenY(Rect.Top);
	SourceRect.Bottom := CalcScreenY(Rect.Top + ScroolLine);
	Canvas.Brush.Color := clBlack;
	Canvas.Brush.Style := bsSolid;
	Canvas.FillRect(SourceRect);
end;


//***************************************************************************
// ������`��
//***************************************************************************
procedure TPromptForm.WriteDisplay(DecodeESCCommand : TDecodeESCCommand);
var
	i : Integer;
	TempRect  : TRect;		// �`��̈�i�Q�o�C�g���p�̏ꍇ�F�ꎟ�`��pTBitmap�j�h�b�g�P��
	DstRect   : TRect;		// �`��̈�iDesCanvas�j�h�b�g�P��
	SrcRect   : TRect;		// TempCanvas or DstCanvas �֕������������̕����̍��W����p
	TempTxt   : String;		// TempCanvas or DstCanvas �֕������������̕`�敶������p
	DstCanvas : TCanvas;	// �`��� Canvas(=Image1.Canvas)
	x, y : Integer;
begin
  DstCanvas := Canvas;
	if(DecodeESCCommand.Attribute.LetterCode = CHAR_ZEN2) then begin
		//-----------------------------------------------------------------------
		// �Q�o�C�g���p
		//-----------------------------------------------------------------------
		TempBitmap.Width  := CalcBitmapX(Length(DecodeESCCommand.Text));
		TempBitmap.Height := CalcScreenY(DecodeESCCommand.Rect.Top + 1)
			- CalcScreenY(DecodeESCCommand.Rect.Top);
		TempRect.Left   := 0;
		TempRect.Top    := 0;
		TempRect.Right  := TempBitmap.Width;
		TempRect.Bottom := TempBitmap.Height;

		DstRect.Left   := CalcScreenX(DecodeESCCommand.Rect.Left);
		DstRect.Top    := CalcScreenY(DecodeESCCommand.Rect.Top);
		DstRect.Right  := CalcScreenX(DecodeESCCommand.Rect.Left + Length(DecodeESCCommand.Text) div 2);
		DstRect.Bottom := CalcScreenY(DecodeESCCommand.Rect.Top + 1);

		// �܂�(�� or ���]�F)�œh��Ԃ�
		if(Reverse in DecodeESCCommand.Attribute.Attribute_Sub) then begin
			TempBitmap.Canvas.Brush.Color := DecodeESCCommand.Attribute.Color;
			TempBitmap.Canvas.Font.Color  := clBlack;
		end else begin
			TempBitmap.Canvas.Brush.Color := clBlack;
			TempBitmap.Canvas.Font.Color  := DecodeESCCommand.Attribute.Color;
		end;

		if(Secret in DecodeESCCommand.Attribute.Attribute_Sub) or
    		((Blink in DecodeESCCommand.Attribute.Attribute_Sub) and (FBlinkOn = False)) then begin
			TempBitmap.Canvas.Font.Color  := TempBitmap.Canvas.Brush.Color;
		end;

    // �w�i��������Ȃ�������h��Ԃ��̈���P�s���炷
		if(TempBitmap.Canvas.Brush.Color = clBlack) then begin
			TempBitmap.Canvas.Brush.Style := bsSolid;
			TempBitmap.Canvas.FillRect(TempRect);
    end else begin
			Dec(TempRect.Bottom);
			TempBitmap.Canvas.Brush.Style := bsSolid;
			TempBitmap.Canvas.FillRect(TempRect);
			Inc(TempRect.Bottom);
    end;

		// �t�H���g�̐ݒ�
		TempBitmap.Canvas.Font.Pitch  := fpFixed;
		TempBitmap.Canvas.Font.Style  := [];
		TempBitmap.Canvas.Font.Height := CalcFontHeight;

		// �P�����Â`�悷��
		i := 0;
		SrcRect.Top    := 0;
		SrcRect.Bottom := TempBitmap.Height;

		while(i + 1 <= Length(DecodeESCCommand.Text)) do begin
			// �P�h�b�g����̌덷�r���̂���
			SrcRect.Left := CalcBitmapX(DecodeESCCommand.Rect.Left + i)
				- CalcBitmapX(DecodeESCCommand.Rect.Left);

			TempTxt := '';
			if(DecodeESCCommand.Text[i+1] in [#$81..#$9f, #$e0..#$fc]) then begin
				// �����P�o�C�g��
        if(DecodeESCCommand.Text[i+1] = #$86) and (DecodeESCCommand.Text[i+2] in [#$a2..#$ed]) then begin
        	// �X�W�r���̏ꍇ
					if(FMPMDForm.InstalledLineFont = False) then begin
						TempBitmap.Canvas.Font.Name :=  STR_MSGOTHIC;
						TempTxt := '�E';
					end else begin
						TempBitmap.Canvas.Font.Name := STR_98LINE;
						TempTxt := #$96 + DecodeESCCommand.Text[i+2];
					end;
        end else begin
					TempBitmap.Canvas.Font.Name := STR_MSGOTHIC;
   				TempTxt := DecodeESCCommand.Text[i+1] + DecodeESCCommand.Text[i+2];
        end;
				Inc(i, 2);
			end else begin
      	// ���p����
				TempTxt := DecodeESCCommand.Text[i+1];
        TempBitmap.Canvas.Font.Name :=  STR_MSGOTHIC;
				Inc(i);
      end;
			TempBitmap.Canvas.TextOut(SrcRect.Left, SrcRect.Top, TempTxt);
		end;

//@	TempBitmap.SaveToFile('r:\aaa.bmp');

		// TempBitmap ���� DstBitmap �։����� 1/2 �ŃR�s�[
		//@ �������K�v�����E�E�E
		if(Reverse in DecodeESCCommand.Attribute.Attribute_Sub) then begin
			for y := 0 to TempBitmap.Height - 1 do begin
				for x := 0 to TempBitmap.Width div 2 - 1 do begin
					DstCanvas.Pixels[DstRect.Left + x, DstRect.Top + y]
						:= $01000000
						or $00ffffff and (not (TempBitmap.Canvas.Pixels[x * 2, y] or TempBitmap.Canvas.Pixels[x * 2 + 1, y]));
				end;
			end;
		end else begin
			for y := 0 to TempBitmap.Height - 1 do begin
				for x := 0 to TempBitmap.Width div 2 - 1 do begin
					DstCanvas.Pixels[DstRect.Left + x, DstRect.Top + y]
						:= TempBitmap.Canvas.Pixels[x * 2, y] or TempBitmap.Canvas.Pixels[x * 2 + 1, y];
				end;
			end;
		end;
  end else begin
		//-----------------------------------------------------------------------
		// �Q�o�C�g���p�ȊO
		//-----------------------------------------------------------------------
		DstRect.Left   := CalcScreenX(DecodeESCCommand.Rect.Left);
		DstRect.Top    := CalcScreenY(DecodeESCCommand.Rect.Top);
		DstRect.Right  := CalcScreenX(DecodeESCCommand.Rect.Left + Length(DecodeESCCommand.Text));
		DstRect.Bottom := CalcScreenY(DecodeESCCommand.Rect.Top + 1);

		// �܂�(�� or ���]�F)�œh��Ԃ�
		if(Reverse in DecodeESCCommand.Attribute.Attribute_Sub) then begin
			DstCanvas.Brush.Color := DecodeESCCommand.Attribute.Color;
			DstCanvas.Font.Color  := clBlack;
		end else begin
			DstCanvas.Brush.Color := clBlack;
			DstCanvas.Font.Color  := DecodeESCCommand.Attribute.Color;
		end;

		if(Secret in DecodeESCCommand.Attribute.Attribute_Sub) or
    		((Blink in DecodeESCCommand.Attribute.Attribute_Sub) and (FBlinkOn = False)) then begin
			DstCanvas.Font.Color  := DstCanvas.Brush.Color;
		end;

    // �w�i��������Ȃ�������h��Ԃ��̈���P�s���炷
		if(DstCanvas.Brush.Color = clBlack) then begin
			DstCanvas.Brush.Style := bsSolid;
			DstCanvas.FillRect(DstRect);
    end else begin
			Dec(DstRect.Bottom);
			DstCanvas.Brush.Style := bsSolid;
			DstCanvas.FillRect(DstRect);
			Inc(DstRect.Bottom);
    end;

		// �t�H���g�̐ݒ�
		DstCanvas.Font.Pitch  := fpFixed;
		DstCanvas.Font.Style  := [];
		DstCanvas.Font.Height := CalcFontHeight;

		// �P�����Â`�悷��
		i := 0;
		SrcRect.Top    := DstRect.Top;
		SrcRect.Bottom := DstRect.Bottom;

		while(i + 1 <= Length(DecodeESCCommand.Text)) do begin
			SrcRect.Left := CalcScreenX(DecodeESCCommand.Rect.Left + i);

      if(DecodeESCCommand.Attribute.LetterCode = CHAR_GRAPHIC) then begin
      	// �O���t�B�b�N����
				if(FMPMDForm.InstalledGraphicFont = False) then begin
        	DstCanvas.Font.Name :=  STR_MSGOTHIC;
					TempTxt := '�';
        end else begin
					DstCanvas.Font.Name := STR_98GRAPHIC;
          if(DecodeESCCommand.Text[i+1] in [#$80..#$9f]) then begin
						TempTxt := Chr(Ord(DecodeESCCommand.Text[i+1]) - $60);
					end else begin
						TempTxt := Chr(Ord(DecodeESCCommand.Text[i+1]) - $a0);
          end;
        end;
				Inc(i);
				SrcRect.Right := CalcScreenX(DecodeESCCommand.Rect.Left + i);

			end else if(DecodeESCCommand.Text[i+1] in [#$81..#$9f, #$e0..#$fc]) then begin
				// �����P�o�C�g��
				TempTxt := DecodeESCCommand.Text[i+1] + DecodeESCCommand.Text[i+2];

				// FMP �O���̔��ʁF$EB9F �` $EC9E
				if(((TempTxt[1] = #$eb) and (TempTxt[2] >= #$9f)) or
						((TempTxt[1] = #$ec) and (TempTxt[2] <= #$9e))) then begin

					// FMP�O�����Ȃ��Ƃ��́u�E�v�ɂ���
					if(FMPMDForm.InstalledFMPFont = False) then begin
						DstCanvas.Font.Name :=  STR_MSGOTHIC;
						TempTxt := '�E';
					end else begin
						DstCanvas.Font.Name := STR_FMPGAIJI;
						TempTxt[1] := Chr(Ord(TempTxt[1]) - $60);
					end;

				// 98�r��(�S�p)�̔��ʁF$86A2 �` $86ED
        end else if(TempTxt[1] = #$86) and (TempTxt[2] in [#$a2..#$ed]) then begin
					if(FMPMDForm.InstalledLineFont = False) then begin
						DstCanvas.Font.Name :=  STR_MSGOTHIC;
						TempTxt := '�E';
					end else begin
						DstCanvas.Font.Name := STR_98LINE;
						TempTxt[1] := Chr(Ord(TempTxt[1]) + $10);
					end;

				end else begin
					DstCanvas.Font.Name :=  STR_MSGOTHIC;
				end;
				Inc(i, 2);
				SrcRect.Right := CalcScreenX(DecodeESCCommand.Rect.Left + i);
			end else begin
				// ���p����
				DstCanvas.Font.Name :=  STR_MSGOTHIC;
				TempTxt := DecodeESCCommand.Text[i+1];
				Inc(i);
				SrcRect.Right := CalcScreenX(DecodeESCCommand.Rect.Left + i);
			end;

			DstCanvas.TextOut(SrcRect.Left, SrcRect.Top, TempTxt);
		end;
	end;


	// �o�[�e�B�J�����C��������
	if(VerticalLine in DecodeESCCommand.Attribute.Attribute_Sub) then begin
		if not(Secret in DecodeESCCommand.Attribute.Attribute_Sub) or
    		((Blink in DecodeESCCommand.Attribute.Attribute_Sub) and (FBlinkOn = False)) then begin
			DstCanvas.Pen.Color := DecodeESCCommand.Attribute.Color;
			DstCanvas.Pen.Width := CalcLineWidth;
			DstCanvas.Pen.Style := psSolid;
			DstCanvas.Pen.Mode  := pmCopy;

			for i := 0 to Length(DecodeESCCommand.Text) - 1 do begin
				DstCanvas.MoveTo((CalcScreenX(DecodeESCCommand.Rect.Left + i)
						+ CalcScreenX(DecodeESCCommand.Rect.Left + i + 1)) div 2 - 1, DstRect.Top);
				DstCanvas.LineTo((CalcScreenX(DecodeESCCommand.Rect.Left + i)
						+ CalcScreenX(DecodeESCCommand.Rect.Left + i + 1)) div 2 - 1, DstRect.Bottom - 1);
			end;
		end;
	end;

	// �A���_�[���C��������
	if(UnderLine in DecodeESCCommand.Attribute.Attribute_Sub) then begin
		if not(Secret in DecodeESCCommand.Attribute.Attribute_Sub) or
    		((Blink in DecodeESCCommand.Attribute.Attribute_Sub) and (FBlinkOn = False)) then begin
			DstCanvas.Pen.Color := DecodeESCCommand.Attribute.Color;
			DstCanvas.Pen.Width := CalcLineWidth;
			DstCanvas.Pen.Style := psSolid;
			DstCanvas.Pen.Mode  := pmCopy;
			DstCanvas.MoveTo(DstRect.Left , DstRect.Bottom - CalcLineWidth);
			DstCanvas.LineTo(DstRect.Right, DstRect.Bottom - CalcLineWidth);
		end;
	end;
end;


//***************************************************************************
// �L�����N�^�x�[�X��X���W����O���t�B�b�N�x�[�X(Screen)��X���W���v�Z����
//***************************************************************************
function TPromptForm.CalcScreenX(CharX : Integer) : Integer;
var
	DrawWidth : Integer;		// �`��̈�̕��@(�ӂ������j
	DrawHeight : Integer;   // �`��̈�̍���(�ӂ������j
begin
	DrawWidth  := ClientWidth  - EdgeWidth * 2;
	DrawHeight := ClientHeight - EdgeWidth * 2;

	if(SCREEN_WIDTH * DrawHeight > SCREEN_HEIGHT * 2 * DrawWidth) then begin	// �c��
		Result := EdgeWidth + DrawWidth * CharX div SCREEN_WIDTH;
	end else begin																														// ����
		Result := EdgeWidth
			+ DrawHeight * CharX div (SCREEN_HEIGHT * 2)
			+ (DrawWidth - DrawHeight * SCREEN_WIDTH div (SCREEN_HEIGHT * 2)) div 2;
	end;
end;


//***************************************************************************
// �L�����N�^�x�[�X��Y���W����O���t�B�b�N�x�[�X(Screen)��Y���W���v�Z����
//***************************************************************************
function TPromptForm.CalcScreenY(CharY : Integer) : Integer;
var
	DrawWidth : Integer;		// �`��̈�̕��@(�ӂ������j
	DrawHeight : Integer;   // �`��̈�̍���(�ӂ������j
begin
	DrawWidth  := ClientWidth  - EdgeWidth * 2;
	DrawHeight := ClientHeight - EdgeWidth * 2;

	if(SCREEN_WIDTH * DrawHeight > SCREEN_HEIGHT * 2 * DrawWidth) then begin	// �c��
		Result := EdgeWidth
			+ DrawWidth * CharY * 2 div SCREEN_WIDTH
			+ (DrawHeight - DrawWidth * SCREEN_HEIGHT * 2 div SCREEN_WIDTH) div 2;
	end else begin																														// ����
		Result := EdgeWidth + DrawHeight * CharY div SCREEN_HEIGHT;
	end;
end;


//***************************************************************************
// �L�����N�^�x�[�X��X���W����O���t�B�b�N�x�[�X(Bitmap)��X���W���v�Z����
//***************************************************************************
function TPromptForm.CalcBitmapX(CharX : Integer) : Integer;
var
	DrawWidth : Integer;		// �`��̈�̕��@(�ӂ������j
	DrawHeight : Integer;   // �`��̈�̍���(�ӂ������j
begin
	DrawWidth  := ClientWidth  - EdgeWidth * 2;
	DrawHeight := ClientHeight - EdgeWidth * 2;

	if(SCREEN_WIDTH * DrawHeight > SCREEN_HEIGHT * 2 * DrawWidth) then begin	// �c��
		Result := DrawWidth * CharX div SCREEN_WIDTH;
	end else begin																														// ����
		Result := DrawHeight * CharX div (SCREEN_HEIGHT * 2);
	end;
end;


//***************************************************************************
// �L�����N�^�x�[�X��Y���W����O���t�B�b�N�x�[�X(Bitmap)��Y���W���v�Z����
//***************************************************************************
function TPromptForm.CalcBitmapY(CharY : Integer) : Integer;
var
	DrawWidth : Integer;		// �`��̈�̕��@(�ӂ������j
	DrawHeight : Integer;   // �`��̈�̍���(�ӂ������j
begin
	DrawWidth  := ClientWidth  - EdgeWidth * 2;
	DrawHeight := ClientHeight - EdgeWidth * 2;

	if(SCREEN_WIDTH * DrawHeight > SCREEN_HEIGHT * 2 * DrawWidth) then begin	// �c��
		Result := DrawWidth * CharY * 2 div SCREEN_WIDTH;
	end else begin																														// ����
		Result := DrawHeight * CharY div SCREEN_HEIGHT;
	end;
end;


//***************************************************************************
// ��ʃT�C�Y����t�H���g�̃T�C�Y(Height)���v�Z����
//***************************************************************************
function TPromptForm.CalcFontHeight : Integer;
var
	DrawWidth : Integer;		// �`��̈�̕��@(�ӂ������j
	DrawHeight : Integer;   // �`��̈�̍���(�ӂ������j
begin
	DrawWidth  := ClientWidth  - EdgeWidth * 2;
	DrawHeight := ClientHeight - EdgeWidth * 2;

	if(SCREEN_WIDTH * DrawHeight > SCREEN_HEIGHT * 2 * DrawWidth) then begin	// �c��
		Result := DrawWidth * 2 div SCREEN_WIDTH;
	end else begin																														// ����
		Result := DrawHeight div SCREEN_HEIGHT;
	end;

  if(Result < 1) then begin
  	Result := 1;
  end;
end;


//***************************************************************************
// ��ʃT�C�Y����������v�Z����
//***************************************************************************
function TPromptForm.CalcLineWidth : Integer;
var
	DrawWidth : Integer;		// �`��̈�̕��@(�ӂ������j
	DrawHeight : Integer;   // �`��̈�̍���(�ӂ������j
begin
	DrawWidth  := ClientWidth  - EdgeWidth * 2;
	DrawHeight := ClientHeight - EdgeWidth * 2;

	if(SCREEN_WIDTH * DrawHeight > SCREEN_HEIGHT * 2 * DrawWidth) then begin	// �c��
		Result := (DrawWidth + ORG_SCREEN_WIDTH div 2) div ORG_SCREEN_WIDTH;
	end else begin																														// ����
		Result := (DrawHeight + ORG_SCREEN_HEIGHT div 2) div ORG_SCREEN_HEIGHT;
	end;
	if(Result < 1) then begin
		Result := 1;
	end;
end;


//###########################################################################
//###########################################################################
// TPromptThread �N���X
//###########################################################################
//###########################################################################

//***************************************************************************
// �R���X�g���N�^
//***************************************************************************
constructor TPromptThread.Create(Owner : TPromptForm);
begin
	FOwner := Owner;
	FDelay := 0;
	FInterval := 50;
	DummyChar := #0;
	pKaraoke := @DummyChar;
	FillChar(FMusData, SizeOf(FMusData), 0);
	FillChar(SyncScntBuf, SizeOf(SyncScntBuf), 0);
	FLastSyncScnt := -1;
	FPMDWinDraw := False;
	FDrawStr := '';
	pw := 0;
	pr := 0;
	DisplayPrompt := False;

	inherited Create(False);
	Priority := tpNormal;
end;


//***************************************************************************
// �f�X�g���N�^
//***************************************************************************
destructor TPromptThread.Destroy;
begin
	inherited Destroy;
end;


//***************************************************************************
// �\���J�n
//***************************************************************************
procedure TPromptThread.PlayStart;
begin
	FillChar(SyncScntBuf, SizeOf(SyncScntBuf), 0);
	FLastSyncScnt := -1;
	pw := 0;
	pr := 0;
	SetDelay(FDelay);
	DisplayPrompt := True;
	FOwner.PositionMove := False;
end;


//***************************************************************************
// �\����~
//***************************************************************************
procedure TPromptThread.PlayStop;
begin
	DisplayPrompt := False;
	FOwner.PositionMove := False;
end;


//***************************************************************************
// �\�� Pause
//***************************************************************************
procedure TPromptThread.PlayPause;
begin
	DisplayPrompt := not DisplayPrompt;
end;


//***************************************************************************
// �Đ��ʒu�ύX�����J�n
//***************************************************************************
procedure TPromptThread.PositionMoveStart;
begin
	FOwner.PositionMove := True;
end;


//***************************************************************************
// �Đ��ʒu�ύX�����I��
//***************************************************************************
procedure TPromptThread.PositionMoveEnd;
var
	i : Integer;
	Len : Integer;
begin
	if(FPlayDriver = DRIVER_FMP) then begin						// WinFMP �̏ꍇ
		if(SyncScntBuf[pw] >= fmp_getsyncscnt) then begin	// �Đ��ʒu���O�ɖ߂����Ƃ�
			Synchronize(InitDisplay);
			FLastSyncScnt := -1;															// �ŏ�����`��
			pKaraoke := @FMusData[PWord(@FMusData[0])^];
			if(StrLComp(pKaraoke, 'FMC', 3) = 0) then begin
				pKaraoke := pKaraoke + 4;
			end else begin
				pKaraoke := @DummyChar;
			end;
		end;

		for i := 0 to NumOfDelayBuffer-1 do begin
			SyncScntBuf[i] := fmp_getsyncscnt;
		end;

    for i := FLastSyncScnt to SyncScntBuf[pr] - 1 do begin
			// ��؂蕶����T��($1b $21)
			Len := Pos(#$1b#$21, String(pKaraoke));
			if(Len > 0) then begin
				FDrawStr := Copy(String(pKaraoke), 1, Len - 1);
				Inc(pKaraoke, Len + 2);
			end else begin
				FDrawStr := String(pKaraoke);
				// �S���I������̂Ń_�~�[�Ɋ֘A�t��
				pKaraoke := @DummyChar;
			end;

			Synchronize(DrawDisplay);
    end;
		FLastSyncScnt := SyncScntBuf[pr];
	end;
	FOwner.PositionMove := False;
	Synchronize(FullDraw);
end;


//***************************************************************************
// FMP �̃v�����v�g�`��
//***************************************************************************
procedure TPromptThread.DrawFMPPrompt;
var
	Len : Integer;
	i : Integer;
begin
		SyncScntBuf[pw] := fmp_getsyncscnt;

		if(SyncScntBuf[pr] > FLastSyncScnt) then begin
			for i := FLastSyncScnt to SyncScntBuf[pr] - 1 do begin
				if(DisplayPrompt = False) or (FOwner.PositionMove = True) then begin
					Break;
				end;

				// ��؂蕶����T��($1b $21)
				Len := Pos(#$1b#$21, String(pKaraoke));
				if(Len > 0) then begin
					FDrawStr := Copy(String(pKaraoke), 1, Len - 1);
					Inc(pKaraoke, Len + 2);
				end else begin
					FDrawStr := String(pKaraoke);
					// �S���I������̂Ń_�~�[�Ɋ֘A�t��
					pKaraoke := @DummyChar;
				end;

				Synchronize(DrawDisplay);
			end;

			FLastSyncScnt := SyncScntBuf[pr];
		end;
end;


//***************************************************************************
// PMD �̃v�����v�g�`��
//***************************************************************************
procedure TPromptThread.DrawPMDPrompt;
var
	i : Integer;
	MemoMsg : Array[0..1024-1] of Char;
begin
	if(FPMDWinDraw = True) then begin
		FPMDWinDraw := False;

		// FileName �̒ǉ�
		getmusicfilename(@MemoMsg[0]);
		FDrawStr := 'Filename : ' + ExtractFileName(String(MemoMsg)) + #$0D#$0A;

		// PPZFile �̒ǉ�
		getmemo(@MemoMsg[0], Nil, 0, -2);
		if(MemoMsg[0] <> #0) then begin
			FDrawStr := FDrawStr + 'PPZFile  : ' + String(MemoMsg) + #$0D#$0A;
		end;

		// PPSFile �̒ǉ�
		getmemo(@MemoMsg[0], Nil, 0, -1);
		if(MemoMsg[0] <> #0) then begin
			FDrawStr := FDrawStr + 'PPSFile  : ' + String(MemoMsg) + #$0D#$0A;
		end;

		// PCMFile �̒ǉ�
		getmemo(@MemoMsg[0], Nil, 0,  0);
		if(MemoMsg[0] <> #0) then begin
			FDrawStr := FDrawStr + 'PCMFile  : ' + String(MemoMsg) + #$0D#$0A;
		end;

		// Title �̒ǉ�
		getmemo(@MemoMsg[0], Nil, 0,  1);
		if(MemoMsg[0] <> #0) then begin
			FDrawStr := FDrawStr + 'Title    : ' + String(MemoMsg) + #$0D#$0A;
		end;

		// Composer �̒ǉ�
		getmemo(@MemoMsg[0], Nil, 0,  2);
		if(MemoMsg[0] <> #0) then begin
			FDrawStr := FDrawStr + 'Composer : ' + String(MemoMsg) + #$0D#$0A;
		end;

		// Arranger �̒ǉ�
		getmemo(@MemoMsg[0], Nil, 0,  3);
		if(MemoMsg[0] <> #0) then begin
			FDrawStr := FDrawStr + 'Arranger : ' + String(MemoMsg) + #$0D#$0A;
		end;

		// Memo �̒ǉ�
		for i := 4 to 255 do begin
			getmemo(@MemoMsg[0], Nil, 0,  i);
			if(MemoMsg[0] = #0) then begin
				Break;
			end;
			FDrawStr := FDrawStr + '         : ' + String(MemoMsg) + #$0D#$0A;
		end;

		Synchronize(DrawDisplay);
	end;
end;


//***************************************************************************
// Interval �ݒ�
//***************************************************************************
procedure TPromptThread.SetInterval(Value : Integer);
begin
	if(Value < 1) then begin
		FInterval := 1;
	end else begin
		FInterval := Value;
	end;
end;


//***************************************************************************
// Delay �ݒ�
//***************************************************************************
procedure TPromptThread.SetDelay(Value : Integer);
begin
	pr := pw - Value div FInterval;
	while(pr < 0) do begin
		Inc(pr, NumOfDelayBuffer);
	end;

	FDelay := Value;
end;


//***************************************************************************
// �ȕύX
//***************************************************************************
procedure TPromptThread.MusicChange(Filename : string; PlayDriver : TPlayDriver);
var
	F : Integer;
begin
	DisplayPrompt := False;
	FillChar(SyncScntBuf, SizeOf(SyncScntBuf), 0);
	FLastSyncScnt := -1;
	pw := 0;
	pr := 0;
	SetDelay(FDelay);

	FPlayDriver := PlayDriver;

	// �ȃf�[�^�ǂݍ���
	FillChar(FMusData, SizeOf(FMusData), 0);
	pKaraoke := @DummyChar;

	F := FileOpen(Filename, fmOpenRead	or fmShareDenyWrite);
	if(F < 0) then begin		// �ǂݍ��ݎ��s
		Exit;
	end;

	// �ǂݍ���
	try
		FileRead(F, FMusData, FMP_MUSDATASIZE);
		if(FPlayDriver = DRIVER_FMP) then begin
			pKaraoke := @FMusData[PWord(@FMusData[0])^];
			if(StrLComp(pKaraoke, 'FMC', 3) = 0) then begin
				pKaraoke := pKaraoke + 4;
			end else begin
				pKaraoke := @DummyChar;
      end;
		end;
	finally
		FileClose(F);
	end;
	FPMDWinDraw := True;
	Synchronize(InitDisplay);
end;


//***************************************************************************
// �S��ʏ���
//***************************************************************************
procedure TPromptThread.InitDisplay;
begin
	(FOwner as TPromptForm).InitDisplay;
end;


//***************************************************************************
// �I�[�i�[��ʂŕ�����`��
//***************************************************************************
procedure TPromptThread.DrawDisplay;
begin
	(FOwner as TPromptForm).DrawDisplay(FDrawStr);
end;


//***************************************************************************
// �I�[�i�[��ʂőS��ʕ`��
//***************************************************************************
procedure TPromptThread.FullDraw;
begin
	(FOwner as TPromptForm).FullDraw;
end;


//***************************************************************************
// �X���b�h���s����
//***************************************************************************
procedure TPromptThread.Execute;
var
	Msg : TMsg;
	Time1, Time2 : Integer;
begin
	while(Terminated = False) do begin
		Time1 := GetTickCount;
		while(PeekMessage(Msg, Integer(Nil), 0, 0, PM_REMOVE)) do begin
			// ���b�Z�[�W����
			case Msg.message of
			WM_PROMPT_MUSICCHANGE:				// �ȕύX
				begin
					MusicChange(String(Msg.LParam), TPlayDriver(Msg.WParam));
					StrDispose(PChar(Msg.LParam));
				end;

			WM_PROMPT_PLAYSTART:					// ���t�J�n
				PlayStart;

			WM_PROMPT_PLAYSTOP:						// ���t��~
				PlayStop;

			WM_PROMPT_PLAYPAUSE:					// Pause
				PlayPause;

			WM_PROMPT_POSITIONMOVESTART:	// ���t�ʒu�ړ��J�n
				PositionMoveStart;

			WM_PROMPT_POSITIONMOVEEND:		// ���t�ʒu�ړ��I��
				PositionMoveEnd;

			end;
		end;

		// ���݂̈ʒu�܂ŕ`�悷��
		if(FPlayDriver = DRIVER_FMP) then begin						// WinFMP �̏ꍇ
			if(DisplayPrompt = True) and (FOwner.PositionMove = False) then begin
				DrawFMPPrompt;
      end;
		end else begin																		// PMDWin �̏ꍇ
			DrawPMDPrompt;
		end;

		if(DisplayPrompt = True) and (FOwner.PositionMove = False) then begin
			Inc(pw);
			if(pw = NumOfDelayBuffer) then pw := 0;
			Inc(pr);
			if(pr = NumOfDelayBuffer) then pr := 0;
		end;

		Time2 := GetTickCount;
		if(FInterval - (Time2 - Time1) > 0) then begin
			Sleep(FInterval - (Time2 - Time1));
		end;
	end;
end;


//###########################################################################
//###########################################################################
// TPromptThread �N���X
//###########################################################################
//###########################################################################

//***************************************************************************
// �R���X�g���N�^
//***************************************************************************
constructor TPromptBlinkThread.Create(Owner : TPromptForm);
begin
	FOwner := Owner;
  RemainTime := BlinkTime[0];
  FInterval := 50;
	inherited Create(False);
end;


//***************************************************************************
// �X���b�h���s����
//***************************************************************************
procedure TPromptBlinkThread.Execute;
var
	Time1, Time2 : Integer;
begin
	while(Terminated = False) do begin
		Time1 := GetTickCount;
		if(RemainTime <= 0) then begin
	  	FOwner.BlinkOn := not FOwner.BlinkOn;
  	  if(FOwner.BlinkOn = False) then begin		// �_�Ł�����
	      Inc(RemainTime, BlinkTime[1]);
    		Synchronize(BlinkDraw);
    	end else begin                        		// ���Ł��_��
	      Inc(RemainTime, BlinkTime[0]);
    		Synchronize(BlinkDraw);
      end;
    end;
    Dec(RemainTime, FInterval);

		Time2 := GetTickCount;
		if(FInterval - (Time2 - Time1) > 0) then begin
			Sleep(FInterval - (Time2 - Time1));
		end;
  end;
end;


//***************************************************************************
// �u�����N�`��
//***************************************************************************
procedure TPromptBlinkThread.BlinkDraw;
begin
	FOwner.BlinkDraw;
end;


//***************************************************************************
// Interval �ݒ�
//***************************************************************************
procedure TPromptBlinkThread.SetInterval(Value : Integer);
begin
	if(Value < 1) then begin
		FInterval := 1;
	end else begin
		FInterval := Value;
	end;
end;


end.

