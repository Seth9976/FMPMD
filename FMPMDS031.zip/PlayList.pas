//============================================================================
//                           PlayList ���j�b�g
//                      Copyright & Programmed by C60
//============================================================================
unit PlayList;

interface

uses
	Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
	StdCtrls, CommDlg, ShellAPI, Menus, FileCtrl, Main, FMPMDPlayDefine, PinForm;

const
	MSG_ERR_LISTINDEX = '���X�g�̃C���f�b�N�X���͈͂𒴂��Ă��܂�';

type
	// PlayList �̃A�C�e��
	PPlayListItem = ^TPlayListItem;
	TPlayListItem = record
		FileName : string;		// �t�@�C���l�[��
		PlayIndex : Integer;	// ���t��
	end;

	// TPlayList(TPlayListItem �p TList�B�v�f�̃������m�ہA�J���͎����I�ɍs��)
	TPlayList = class(TList)
	protected
		function Get(Index: Integer): PPlayListItem;
		procedure Put(Index: Integer; Item: PPlayListItem);
	public
		destructor Destroy; override;
		function Add(Item: TPlayListItem): Integer;
		procedure Clear;
		procedure Delete(Index: Integer);
		procedure Insert(Index: Integer; Item: TPlayListItem);
		property Items[Index: Integer]: PPlayListItem read Get write Put; default;
	end;

	// ��O
	EPlayListError = class(Exception);

	TPlayListForm = class(TForm)
		ListBox1: TListBox;
		PinForm1: TPinForm;
		PopupMenu1: TPopupMenu;
		CutPopup: TMenuItem;
		CopyPopup: TMenuItem;
		PastePopup: TMenuItem;
		N1: TMenuItem;
		SelectAllPopup: TMenuItem;
		procedure FormCreate(Sender: TObject);
		procedure ListBox1DblClick(Sender: TObject);
		procedure ListBox1KeyDown(Sender: TObject; var Key: Word;
			Shift: TShiftState);
		procedure ListBox1DragOver(Sender, Source: TObject; X, Y: Integer;
			State: TDragState; var Accept: Boolean);
		procedure ListBox1DragDrop(Sender, Source: TObject; X, Y: Integer);
		procedure FormDestroy(Sender: TObject);
		procedure PopupMenu1Popup(Sender: TObject);
		procedure Cut(Sender: TObject);
		procedure Copy(Sender: TObject);
		procedure Paste(Sender: TObject);
		procedure SelectAll(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormActivate(Sender: TObject);
	private
		{ Private �錾 }
		FPlayList : TPlayList;		// PlayList �̎���
		FPlayCount : Integer;			// ���t���̋Ȃ̔ԍ�(TPlayListItem.PlayIndex �ɑΉ�)
		FPlayListCount : Integer;	// PlayList �Ȑ�(FPlayList.Count)
		FSelectExt : TStringList;	// �t�H���_���̎��ʊg���q('.'���܂�)
		FLoop : Boolean;
		FRandom : Boolean;
		FOnSelect : TNotifyEvent;
		FStrClip : TStringList;		// �N���b�v
	protected
		procedure WindowPosChanging(var Msg : TWMWindowPosChanging); message WM_WINDOWPOSCHANGING;
		procedure DropFiles(var Msg:TWMDROPFILES); message WM_DROPFILES;
		function GetPlayFileName : String;
		function GetCount : Integer;
		procedure SetRandom(Value : Boolean);
		procedure OnlySelect(Index : Integer);
		procedure SetPlayIndex(Value : Integer);
		function GetPlayIndex : Integer;
		procedure SetSelectExt(Value : TStrings);
		function GetSelectExt : TStrings;
	public
		{ Public �錾 }
		procedure Add(Item: String);
		procedure AddStrings(Strings: TStrings);
		procedure Insert(Index: Integer; Item : String);
		procedure InsertStrings(Index: Integer; Strings: TStrings);
		procedure InsertStringsSub(Index: Integer; Strings: TStrings);
		procedure Clear;
		procedure Delete(Index : Integer);
		function Next : Boolean;
		function Prev : Boolean;
		procedure LoadFromFile(const FileName: string);
		procedure SaveToFile(const FileName: string);
		property PlayFileName : string read GetPlayFileName;
		property Loop : Boolean read FLoop write FLoop;
		property Random : Boolean read FRandom write SetRandom;
		property Count : Integer read GetCount;
		property PlayIndex : Integer read GetPlayIndex write SetPlayIndex;
		property SelectExt : TStrings read GetSelectExt write SetSelectExt;
		property OnSelect : TNotifyEvent read FOnSelect write FOnSelect;
	end;

var
	PlayListForm: TPlayListForm;

implementation

{$R *.DFM}


//###########################################################################
//###########################################################################
// TPlayList �N���X
//###########################################################################
//###########################################################################

//***************************************************************************
// �f�X�g���N�^
//***************************************************************************
destructor TPlayList.Destroy;
(*
var
	i : Integer;
*)
begin
(*
	// Item �̊J��
	for i := 0 to Count-1 do begin
		Dispose(inherited Items[i]);
	end;
*)
	Clear;
	inherited Destroy;
end;


//***************************************************************************
// Item �ǉ�
//***************************************************************************
function TPlayList.Add(Item: TPlayListItem): Integer;
var
	p_PlayListItem : PPlayListItem;
begin
	New(p_PlayListItem);
	p_PlayListItem^ := Item;
	result := inherited Add(p_PlayListItem);
end;


//***************************************************************************
// Item �}��
//***************************************************************************
procedure TPlayList.Insert(Index: Integer; Item: TPlayListItem);
var
	p_PlayListItem : PPlayListItem;
begin
	New(p_PlayListItem);
	p_PlayListItem^ := Item;
	inherited Insert(Index, p_PlayListItem);
end;


//***************************************************************************
// Item �폜
//***************************************************************************
procedure TPlayList.Delete(Index: Integer);
begin
	if (Index < 0) or (Index >= Count) then EPlayListError.Create(MSG_ERR_LISTINDEX);
	if(Items[Index] <> nil) then begin
		Dispose(inherited Items[Index]);
		inherited Delete(Index);
		Pack;
	end;
end;


//***************************************************************************
// Item �S�폜
//***************************************************************************
procedure TPlayList.Clear;
var
	i : Integer;
begin
	// Item �̊J��
	for i := 0 to Count-1 do begin
		if(Items[i] <> nil) then begin
			Dispose(inherited Items[i]);
		end;
	end;
	inherited Clear;
	Pack;
end;


//***************************************************************************
// Item �擾
//***************************************************************************
function TPlayList.Get(Index : Integer) : PPlayListItem;
begin
	result := inherited Get(Index);
end;


//***************************************************************************
// Item ���
//***************************************************************************
procedure TPlayList.Put(Index: Integer; Item: PPlayListItem);
begin
	TPlayListItem(inherited Items[Index]^) := Item^;
end;


//###########################################################################
//###########################################################################
// TPlayListForm �N���X
//###########################################################################
//###########################################################################

//***************************************************************************
// �R���X�g���N�^
//***************************************************************************
procedure TPlayListForm.FormCreate(Sender: TObject);
begin
	DragAcceptFiles(Handle, True);
	FOnSelect := Nil;
	FPlayCount := 0;
	FPlayListCount := 0;
	FLoop := False;
	FRandom := False;
	FPlayList := TPlayList.Create;
	FStrClip := TStringList.Create;
	FSelectExt := TStringList.Create;
	Randomize;
end;


//***************************************************************************
// �f�X�g���N�^
//***************************************************************************
procedure TPlayListForm.FormDestroy(Sender: TObject);
begin
	FPlayList.Destroy;
	FStrClip.Destroy;
	FSelectExt.Destroy;
end;


//***************************************************************************
// Window �ւ� D&D
//***************************************************************************
procedure TPlayListForm.DropFiles(var Msg:TWMDROPFILES);
var
	FileName: array[0..1024] of Char;
	i, Files : Integer;
	StrList : TStringList;
begin
	StrList := TStringList.Create;
	try
		// ��ۯ�߂��ꂽ̧�ِ����擾
		Files:= DragQueryFile(Msg.Drop, $ffffffff, nil, 0);
		// �t�@�C���̃��X�g��ListBox�ɑ������
		for i:= 0 to Files - 1 do begin
			DragQueryFile(Msg.Drop, i, FileName, Sizeof(FileName) - 1);
			StrList.Add(FileName);
		end;
		// �I������
		DragFinish(Msg.Drop);
		AddStrings(StrList);
	finally
		Msg.result := 0;
		StrList.Destroy;
	end;
end;


//***************************************************************************
// �t�H�[�����J�����Ƃ�
//***************************************************************************
procedure TPlayListForm.FormActivate(Sender: TObject);
begin
	FMPMDForm.PlayListMenu.Checked := True;
end;


//***************************************************************************
// �t�H�[��������Ƃ�
//***************************************************************************
procedure TPlayListForm.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
	FMPMDForm.PlayListMenu.Checked := False;
end;


//***************************************************************************
// ���t���t�@�C���̎擾
//***************************************************************************
function TPlayListForm.GetPlayFileName : String;
var
	i : Integer;
begin
	if(FPlayCount < FPlayListCount) then begin
		for i := 0 to FPlayListCount-1 do begin
			if(FPlayCount = FPlayList[i].PlayIndex) then begin
				result := FPlayList[i].FileName;
				break;
			end;
		end;
		OnlySelect(FPlayCount);
	end else begin
		result := '';
	end;
end;


//***************************************************************************
// �v���C���X�g�̋Ȑ��̎擾
//***************************************************************************
function TPlayListForm.GetCount : Integer;
begin
	// Thread �΍�� VCL ���g�킸�Ɏ擾
	result := FPlayListCount;
end;


//***************************************************************************
// Random ��ݒ�
//***************************************************************************
procedure TPlayListForm.SetRandom(Value : Boolean);
var
	i, j, k, temp : Integer;
	FPlayCount2 : Integer;
begin
	if(Value = True) then begin
		// PlayList ���V���b�t������
		// �����t���Ă���Ȃ� PlayIndex �� 0�A����ȊO�̋Ȃ� PlayIndex ����U
		// -1 �ɃZ�b�g���A��� -1 �̕����ɔԍ���U���Ă���
		for i := 0 to FPlayListCount-1 do begin
			if(FPlayList[i].PlayIndex = FPlayCount) then begin
				FPlayList[i].PlayIndex := 0;
			end else begin
				FPlayList[i].PlayIndex := -1;
			end;
		end;
		FPlayCount := 0;

		for i := 1 to FPlayListCount-1 do begin
			temp := System.Random(FPlayListCount - i) + 1;
			k := 0;
			for j := 0 to FPlayListCount-1 do begin
				if(FPlayList[j].PlayIndex < 0) then begin
					Inc(k);
					if(k = temp) then begin
						FPlayList[j].PlayIndex := i;
						break;
					end;
				end;
			end;
		end;
	end else begin
		// ���݉��t���̋Ȃ� FPlayList �ł̈ʒu��T��
		FPlayCount2 := -1;
		for i := 0 to FPlayListCount - 1 do begin
			if(FPlayList[i].PlayIndex = FPlayCount) then begin
				FPlayCount2 := i;
				break;
			end;
		end;

		// PlayList �̃V���b�t����߂�
		for i := 0 to FPlayListCount - 1 do begin
			FPlayList[i].PlayIndex := i;
		end;

		// ���݉��t���̋Ȃ� FPlayList �ł̈ʒu��ݒ肵����
		if(FPlayListCount > 0) and (FPlayCount2 >= 0) then begin
			FPlayCount := FPlayCount2;
		end else begin
			FPlayCount := 0;
		end;
	end;
	FRandom := Value;
end;


//***************************************************************************
// SelectExt(�t�H���_��I�������Ƃ��̑I���g���q)��ݒ�
//***************************************************************************
procedure TPlayListForm.SetSelectExt(Value : TStrings);
var
	i : Integer;
begin
	FSelectExt.Clear;

	for i := 0 to Value.Count - 1 do begin
		if(Value[i][1] = '.') then begin				// '.' ������ꍇ
			FSelectExt.Add(LowerCase(Value[i]));
		end else begin													// '.' ���Ȃ��ꍇ
			FSelectExt.Add(LowerCase('.' + Value[i]));
		end;
	end;
end;


//***************************************************************************
// SelectExt(�t�H���_��I�������Ƃ��̑I���g���q)���擾
//***************************************************************************
function TPlayListForm.GetSelectExt : TStrings;
begin
	Result := FSelectExt;
end;


//***************************************************************************
// �ȁi�P�j���v���C���X�g�ɒǉ�
//***************************************************************************
procedure TPlayListForm.Add(Item: String);
var
	StrList : TStringList;
begin
	StrList := TStringList.Create;
	StrList.Add(Item);
	InsertStrings(FPlayListCount, StrList);
	StrList.Destroy;
end;


//***************************************************************************
// �ȁi�P�j���v���C���X�g�ɑ}��
//***************************************************************************
procedure TPlayListForm.Insert(Index: Integer; Item: String);
var
	StrList : TStringList;
begin
	StrList := TStringList.Create;
	StrList.Add(Item);
	InsertStrings(Index, StrList);
	StrList.Destroy;
end;


//***************************************************************************
// �ȁi�����j���v���C���X�g�ɒǉ�
//***************************************************************************
procedure TPlayListForm.AddStrings(Strings: TStrings);
begin
	InsertStrings(FPlayListCount, Strings);
end;


//***************************************************************************
// �ȁi�����j���v���C���X�g�ɑ}��
//***************************************************************************
procedure TPlayListForm.InsertStrings(Index: Integer; Strings: TStrings);
var
	i, j, k, temp : Integer;
begin
	InsertStringsSub(Index, Strings);
	
	if(FRandom = True) then begin
		// Random �̏ꍇ�A���݉��t���̋Ȉȍ~���V���b�t������
		// �i����0�Ȃ̏ꍇ�S���V���b�t���j
		// �����t���Ă���Ȉȍ~�� PlayIndex ����U -1 �ɃZ�b�g���A���
		// -1 �̕����ɔԍ���U���Ă���
		if(FPlayListCount = 0) then begin
			for i := 0 to FPlayList.Count-1 do begin
				FPlayList[i].PlayIndex := -1;
			end;

			FPlayCount := 0;

			for i := 0 to FPlayList.Count-1 do begin
				temp := System.Random(FPlayList.Count - i) + 1;
				k := 0;
				for j := 0 to FPlayList.Count-1 do begin
					if(FPlayList[j].PlayIndex < 0) then begin
						Inc(k);
						if(k = temp) then begin
							FPlayList[j].PlayIndex := i;
							break;
						end;
					end;
				end;
			end;
		end else begin
			for i := 0 to FPlayList.Count-1 do begin
				if(FPlayList[i].PlayIndex > FPlayCount) then begin
					FPlayList[i].PlayIndex := -1;
				end;
			end;

			for i := FPlayCount + 1 to FPlayList.Count-1 do begin
				temp := System.Random(FPlayList.Count - i) + 1;
				k := 0;
				for j := 0 to FPlayList.Count-1 do begin
					if(FPlayList[j].PlayIndex < 0) then begin
						Inc(k);
						if(k = temp) then begin
							FPlayList[j].PlayIndex := i;
							break;
						end;
					end;
				end;
			end;
		end;
	end else begin
		// Random �ł͂Ȃ��ꍇ�A���Ԃ�ł������Č��݉��t���̃t�@�C����
		// FPlayCount �ɃZ�b�g����
		for i := 0 to FPlayList.Count-1 do begin
			FPlayList[i].PlayIndex := i;
		end;

		if(FPlayCount > Index) then begin
			Inc(FPlayCount, Index);
		end;
	end;

	FPlayListCount := FPlayList.Count;
	OnlySelect(FPlayCount);
end;


//***************************************************************************
// �ȁi�����j���v���C���X�g�ɑ}��(�������E�}�������̂�)
//***************************************************************************
procedure TPlayListForm.InsertStringsSub(Index: Integer; Strings: TStrings);
var
	StrList : TStringList;
	FolderList : TStringList;
	i, j : Integer;
	InsertCount : Integer;									// �t�@�C����}��������
	PlayListItem : TPlayListItem;
  SearchRec: TSearchRec;
  Rslt : Integer;
begin
	InsertCount := Index;
	StrList := TStringList.Create;
	FolderList := TStringList.Create;
	
	// ListBox �X�V��}��
	ListBox1.Items.BeginUpdate;
	
	// PlayList ��W�J�AFPlayList �֊i�[
	for i := 0 to Strings.Count-1 do begin
		if(LowerCase(ExtractFileExt(Strings[i])) = PlayListExt) then begin
			// PlayList �̏ꍇ�F�W�J���Ċi�[
			StrList.Clear;
			StrList.LoadFromFile(Strings[i]);

			for j := 0 to StrList.Count-1 do begin
				if(StrList[j][1] <> '#') then begin
					if(FileExists(StrList[j])) then begin
						// FPlayList �֊i�[
						PlayListItem.FileName := StrList[j];
						PlayListItem.PlayIndex := FPlayList.Count;
						FPlayList.Insert(InsertCount, PlayListItem);
						ListBox1.Items.Insert(InsertCount, StrList[j]);
						Inc(InsertCount);
					end;
				end;
			end;
		end else if(DirectoryExists(Strings[i]) = True) then begin
			// �t�H���_�̏ꍇ�F��U FolderList �ɕۑ�����
			// �ォ�珈��(�t�@�C���̏������̊֌W)
			FolderList.Add(Strings[i]);
		end else begin
			// �ȃf�[�^�̏ꍇ
			if(FileExists(Strings[i])) then begin
				// FPlayList �֊i�[
				PlayListItem.FileName := Strings[i];
				PlayListItem.PlayIndex := FPlayList.Count;
				FPlayList.Insert(InsertCount, PlayListItem);
				ListBox1.Items.Insert(InsertCount, Strings[i]);
				Inc(InsertCount);
			end;
		end;
	end;
	
	// ListBox �X�V���ĊJ
	ListBox1.Items.EndUpdate;
	
	// ���ʃt�H���_����w��g���q�i�{�t�H���_�j�̃t�@�C����
	// �I������ StrList �ɕۑ�
	StrList.Clear;		// �g���܂킵
	
	for i := 0 to FolderList.Count - 1 do begin
		Rslt := FindFirst(FolderList[i]+'\*.*',
			faReadOnly+faHidden+faSysFile+faDirectory+faArchive, SearchRec);
		if(Rslt = 0) then begin
			while(Rslt = 0) do begin
				if((SearchRec.Attr and faDirectory) > 0) then begin
					// �t�H���_�̏ꍇ '.' �܂��� '..' �łȂ���Ζ������ɒǉ�
					if(SearchRec.Name <> '.') and (SearchRec.Name <> '..') then begin
						StrList.Add(FolderList[i] + '\' + SearchRec.Name);
					end;
				end else if(FSelectExt.Count = 0) then begin
					// FSelectExt ���ݒ肳��Ă��Ȃ���Ζ������ɒǉ�
					StrList.Add(FolderList[i] + '\' + SearchRec.Name);
				end else begin
					// �t�@�C���̏ꍇ�AFSelectExt �ɂ���Βǉ�
					if(FSelectExt.IndexOf(LowerCase(ExtractFileExt(SearchRec.Name))) >= 0)
							then begin
						StrList.Add(FolderList[i] + '\' + SearchRec.Name);
					end;
				end;
				Rslt := FindNext(SearchRec);
			end;
			
			FindClose(SearchRec);
		end;
	end;
	
	// �ċA�Ăяo��
	if(StrList.Count > 0) then begin
		InsertStringsSub(FPlayList.Count, StrList);
	end;
	
	FolderList.Destroy;
	StrList.Destroy;
	
end;


//***************************************************************************
// �Ȃ��v���C���X�g����폜
//***************************************************************************
procedure TPlayListForm.Delete(Index : Integer);
var
	i : Integer;
begin
	// �폜������̂���� Item �� PlayIndex ���P�O�ւ��炷
	for i := 0 to FPlayListCount-1 do begin
		if(FPlayList[i].PlayIndex > FPlayList[Index].PlayIndex) then begin
			Dec(FPlayList[i].PlayIndex);
		end;
	end;

	// �폜����
	if(FPlayList[Index].PlayIndex <= FPlayCount) then begin
		Dec(FPlayCount);
		if(FPlayCount < 0) then begin
			FPlayCount := 0;
		end;
	end;

	FPlayList.Delete(Index);
	ListBox1.Items.Delete(Index);
	Dec(FPlayListCount);
end;


//***************************************************************************
// ���̋ȂփV�[�N
//	return :	�Ȑ����O���A�ȃ��X�g�̍Ō��
//						loop flag �������Ă��Ȃ������� false
//***************************************************************************
function TPlayListForm.Next : Boolean;
begin
	result := True;
	if(FPlayListCount > 0) then begin
		if(FPlayCount + 1>= FPlayListCount) then begin
			if(FLoop = False) then begin
				result := False;
			end else begin
				FPlayCount := 0;
				OnlySelect(FPlayCount);
			end;
		end else begin
			Inc(FPlayCount);
			OnlySelect(FPlayCount);
		end;
	end else begin
		Result := False;
	end;
end;


//***************************************************************************
// �O�̋ȂփV�[�N
//	return :	�Ȑ����O���A�ȃ��X�g�̐擪��
//						loop flag �������Ă��Ȃ������� false
//***************************************************************************
function TPlayListForm.Prev : Boolean;
begin
	result := True;
	if(FPlayListCount > 0) then begin
		if(FPlayCount = 0) then begin
			if(FLoop = False) then begin
				result := False;
			end else begin
				FPlayCount := FPlayListCount - 1;
				OnlySelect(FPlayCount);
			end;
		end else begin
			Dec(FPlayCount);
			OnlySelect(FPlayCount);
		end;
	end else begin
		Result := False;
	end;
end;


//***************************************************************************
// �Ȃ��N���A
//***************************************************************************
procedure TPlayListForm.Clear;
begin
	FPlayList.Clear;
	ListBox1.Clear;
	FPlayListCount := 0;
	FPlayCount := 0;
end;


//***************************************************************************
// PlayList ��ǂݍ���(M3U�`��)
//***************************************************************************
procedure TPlayListForm.LoadFromFile(const FileName: string);
begin
	Clear;
	Add(FileName);
end;


//***************************************************************************
// PlayList ��ۑ�(M3U�`��)
//***************************************************************************
procedure TPlayListForm.SaveToFile(const FileName: string);
var
	i : Integer;
	F: TextFile;
begin
	AssignFile(F, FileName);
	ReWrite(F);

	for i := 0 to FPlayListCount-1 do begin
		Writeln(F, FPlayList[i].FileName);
	end;
	CloseFile(F);
end;


//***************************************************************************
// ���t�Ȃ��擾(ListBox ����)
//***************************************************************************
function TPlayListForm.GetPlayIndex : Integer;
var
	i : Integer;
begin
	if(FPlayListCount = 0) then begin
		result := 0;
	end else begin
		// ���݉��t���̋Ȃ� FPlayList �ł̈ʒu���擾����
		result := -1;
		for i := 0 to FPlayListCount - 1 do begin
			if(FPlayList[i].PlayIndex = FPlayCount) then begin
				result := i;
				break;
			end;
		end;

		// ������Ȃ�����
		if(result < 0) then result := 0;
	end;
end;


//***************************************************************************
// ���t�Ȃ��w��(ListBox ����)
//***************************************************************************
procedure TPlayListForm.SetPlayIndex(Value : Integer);
begin
	if(Value >= FPlayListCount) then begin
		FPlayCount := 0;
	end else begin
		FPlayCount := FPLayList[Value].PlayIndex;
		OnlySelect(FPlayCount);
	end;
end;


//***************************************************************************
// ListBox ����P���ڂ̂ݑI��
//***************************************************************************
procedure TPlayListForm.OnlySelect(Index : Integer);
var
	i : Integer;
begin
	for i := 0 to FPlayListCount-1 do begin
		if(FPlayList[i].PlayIndex = Index) then begin
			ListBox1.Selected[i] := True;
			SendMessage(ListBox1.Handle, LB_SETCARETINDEX, i, 0);
		end else begin
			if(ListBox1.Selected[i] = True) then begin
				ListBox1.Selected[i] := False;
			end;
		end;
	end;
end;


//***************************************************************************
// Window �̃X�i�b�v
//***************************************************************************
procedure TPlayListForm.WindowPosChanging(var Msg : TWMWindowPosChanging);
begin
	if(FMPMDForm.Snap = True) then begin
		Msg.WindowPos^.x := (Msg.WindowPos^.x div FMPMDForm.SnapWidth) * FMPMDForm.SnapWidth;
		Msg.WindowPos^.y := (Msg.WindowPos^.y div FMPMDForm.SnapWidth) * FMPMDForm.SnapWidth;
		Msg.WindowPos^.cx := (Msg.WindowPos^.cx div FMPMDForm.SnapWidth) * FMPMDForm.SnapWidth;
		Msg.WindowPos^.cy := (Msg.WindowPos^.cy div FMPMDForm.SnapWidth) * FMPMDForm.SnapWidth;
	end;

  inherited;
end;


//***************************************************************************
// ���X�g�{�b�N�X���_�u���N���b�N���ꂽ
//***************************************************************************
procedure TPlayListForm.ListBox1DblClick(Sender: TObject);
begin
	if Assigned(FOnSelect) then begin
		FPlayCount := FPlayList[ListBox1.ItemIndex].PlayIndex;
		FOnSelect(Self);
	end;
end;


//***************************************************************************
// Popup ���j���[�\�����̓���
//***************************************************************************
procedure TPlayListForm.PopupMenu1Popup(Sender: TObject);
begin
	if(ListBox1.ItemIndex < 0) or (FPlayListCount = 0) then begin
		CutPopup.Enabled := False;
		CopyPopup.Enabled := False;
	end else begin
		CutPopup.Enabled := True;
		CopyPopup.Enabled := True;
	end;

	if(FStrClip.Count <= 0) then begin
		PastePopup.Enabled := False;
	end else begin
		PastePopup.Enabled := True;
	end;

	if(FPlayListCount <= 0) then begin
		SelectAllPopup.Enabled := False;
	end else begin
		SelectAllPopup.Enabled := True;
	end;
end;


//***************************************************************************
// �L�[����
//***************************************************************************
procedure TPlayListForm.ListBox1KeyDown(Sender: TObject; var Key: Word;
	Shift: TShiftState);
var
	i : Integer;
begin
	if(Key = VK_RETURN) then begin
		// Enter �L�[�������ꂽ
		if(ListBox1.ItemIndex >= 0) and Assigned(FOnSelect) then begin
			FPlayCount := FPlayList[ListBox1.ItemIndex].PlayIndex;
			FOnSelect(Self);
		end;
	end else if(Key = VK_DELETE) then begin
		// Delete �L�[�������ꂽ
		for i := FPlayListCount-1 downto 0 do begin
			if(ListBox1.Selected[i] = True) then begin
				Delete(i);
			end;
		end;
	end else if(Shift = [ssCtrl]) then begin
		case Chr(Key) of
			'X', 'x' : Cut(Self);					// CTRL + X
			'C', 'c' : Copy(Self);        // CTRL + C
			'V', 'v' : Paste(Self);       // CTRL + V
			'A', 'a' : SelectAll(Self);   // CTRL + A
		end;
	end;
end;


//***************************************************************************
// �؂���
//***************************************************************************
procedure TPlayListForm.Cut(Sender: TObject);
var
	i : Integer;
begin
	FStrClip.Clear;
	i := 0;
	while(i < FPlayListCount) do begin
		if(ListBox1.Selected[i] = True) then begin
			FStrClip.Add(FPlayList[i].FileName);
			Delete(i);
		end else begin
			Inc(i);
		end;
	end;
end;


//***************************************************************************
// �R�s�[
//***************************************************************************
procedure TPlayListForm.Copy(Sender: TObject);
var
	i : Integer;
begin
	FStrClip.Clear;
	i := 0;
	while(i < FPlayListCount) do begin
		if(ListBox1.Selected[i] = True) then begin
			FStrClip.Add(FPlayList[i].FileName);
		end;
		Inc(i);
	end;
end;


//***************************************************************************
// �\��t��
//***************************************************************************
procedure TPlayListForm.Paste(Sender: TObject);
begin
	if(ListBox1.ItemIndex < 0) then begin
		AddStrings(FStrClip);
	end else begin
		InsertStrings(ListBox1.ItemIndex + 1, FStrClip);
	end;
end;


//***************************************************************************
// ���ׂđI��
//***************************************************************************
procedure TPlayListForm.SelectAll(Sender: TObject);
var
	i : Integer;
begin
	for i := 0 to FPlayListCount-1 do begin
		ListBox1.Selected[i] := true;
	end;
end;


//***************************************************************************
// �h���b�v�󂯓���
//***************************************************************************
procedure TPlayListForm.ListBox1DragOver(Sender, Source: TObject; X,
	Y: Integer; State: TDragState; var Accept: Boolean);
begin
//	Accept := True;
end;


//***************************************************************************
// �h���b�v���ꂽ�ۂ̓���ւ�
//***************************************************************************
procedure TPlayListForm.ListBox1DragDrop(Sender, Source: TObject; X,
	Y: Integer);
//var
//	i : Integer;
begin
(*
	if(Sender is TListBox) and (Source is TListBox) then begin

		//@ �s�̓���ւ��i�}����̎擾�@�́H�j
		for i := FPlayListCount-1 downto 0 do begin
			if(ListBox1.Selected[i] = True) then begin
				Delete(i);
			end;
		end;
	end;
*)
end;


end.
